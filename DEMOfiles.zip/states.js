const states = "Alabama\n" +
    "Alaska\n" +
    "Arizona\n" +
    "Arkansas\n" +
    "California\n" +
    "Colorado\n" +
    "Connecticut\n" +
    "Delaware\n" +
    "Florida\n" +
    "Georgia\n" +
    "Hawaii\n" +
    "Idaho\n" +
    "Illinois\n" +
    "Indiana\n" +
    "Iowa\n" +
    "Kansas\n" +
    "Kentucky\n" +
    "Louisiana\n" +
    "Maine\n" +
    "Maryland\n" +
    "Massachusetts\n" +
    "Michigan\n" +
    "Minnesota\n" +
    "Mississippi\n" +
    "Missouri\n" +
    "Montana\n" +
    "Nebraska\n" +
    "Nevada\n" +
    "New Hampshire\n" +
    "New Jersey\n" +
    "New Mexico\n" +
    "New York\n" +
    "North Carolina\n" +
    "North Dakota\n" +
    "Ohio\n" +
    "Oklahoma\n" +
    "Oregon\n" +
    "Pennsylvania\n" +
    "Rhode Island\n" +
    "South Carolina\n" +
    "South Dakota\n" +
    "Tennessee\n" +
    "Texas\n" +
    "Utah\n" +
    "Vermont\n" +
    "Virginia\n" +
    "Washington\n" +
    "West Virginia\n" +
    "Wisconsin\n" +
    "Wyoming\n" +
    "\n";