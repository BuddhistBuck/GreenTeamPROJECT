let WPM = 200;
let finalArray = [];

function convertToArray(string) {
    let tempString = "";
    for (let i = 0, len = string.length; i < len; i++) {
         if (string[i] === "\n" ) {
            finalArray.push(tempString);
            tempString = "";
        } else {
            tempString += string[i];
        }
    }
    return finalArray;
}

async function testDisplaySpeed(finalArray, WPM) {
    let WPS = 60 / WPM * 1000;
    let sleep = millisecond => new Promise(whatIsDelay => setTimeout(whatIsDelay, millisecond));
    for (let i = 0, len = finalArray.length; i < len; i++) {
        let numberOfWords = finalArray[i].split(" ").length;
        let combinedWPS = WPS * numberOfWords;
        document.getElementById("words").innerHTML = finalArray[i];
        await sleep(combinedWPS);
    }
}